﻿namespace OTPS
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headerLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.routeCmb = new System.Windows.Forms.ComboBox();
            this.conBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // headerLbl
            // 
            this.headerLbl.AutoSize = true;
            this.headerLbl.Location = new System.Drawing.Point(235, 28);
            this.headerLbl.Name = "headerLbl";
            this.headerLbl.Size = new System.Drawing.Size(138, 13);
            this.headerLbl.TabIndex = 0;
            this.headerLbl.Text = "Online Toll Payment System";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(96, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(437, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome to the online Toll Payment System. To proceed, please select your route o" +
    "f travel.";
            // 
            // routeCmb
            // 
            this.routeCmb.FormattingEnabled = true;
            this.routeCmb.Items.AddRange(new object[] {
            "Vashi\t<->\tKhandala\t\t(via Panvel-Pune Expressway)",
            "Vashi\t<->\tPune\t\t(via Panvel-Pune Expressway)",
            "Vashi\t<->\tGoa\t\t(via NH4)",
            "Vashi\t<->\tMumbai CST\t(via Eastern Freeway)",
            "Mulund\t<->\tChembur\t\t(via Eastern Express Highway)",
            "Mulund\t<->\tGodbandar\t(via Thane)",
            "Vashi\t<->\tAlibaug\t\t(via Pen)",
            "Delhi\t<->\tMathura\t\t(via Yamuna Expressway)",
            "Delhi\t<->\tAgra\t\t(via Yamuna Expressway)",
            "Delhi\t<->\tShimla\t\t(via Chandigarh)"});
            this.routeCmb.Location = new System.Drawing.Point(133, 104);
            this.routeCmb.Name = "routeCmb";
            this.routeCmb.Size = new System.Drawing.Size(360, 21);
            this.routeCmb.TabIndex = 3;
            this.routeCmb.Text = "Choose your Route...";
            // 
            // conBtn
            // 
            this.conBtn.Location = new System.Drawing.Point(238, 254);
            this.conBtn.Name = "conBtn";
            this.conBtn.Size = new System.Drawing.Size(140, 26);
            this.conBtn.TabIndex = 4;
            this.conBtn.Text = "Continue";
            this.conBtn.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(238, 131);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 105);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 330);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.conBtn);
            this.Controls.Add(this.routeCmb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.headerLbl);
            this.Name = "Home";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label headerLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox routeCmb;
        private System.Windows.Forms.Button conBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}


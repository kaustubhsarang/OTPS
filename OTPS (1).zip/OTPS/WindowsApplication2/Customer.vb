﻿Imports System.Data.SqlClient
Public Class Customer

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Hide()
        MakePayment.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        Dim rd As SqlDataReader
        con.ConnectionString = " Data Source=(LocalDB)\v11.0;AttachDbFilename='C:\Users\kaustubh\Documents\Visual Studio 2013\Projects\OTPS\WindowsApplication2\Database1.mdf';Integrated Security=True"
        cmd.Connection = con
        con.Open()
        cmd.CommandText = "INSERT into customer  VALUES('" + TextBox1.Text + "," + TextBox2.Text + "," + TextBox3.Text + "," + TextBox5.Text + "," + TextBox6.Text + "')"
        con.Close()
    






    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub
End Class

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package otps;
import org.json.simple.JSONObject;
import java.util.*;
import java.io.*;
import org.json.simple.JSONArray;
import org.json.simple.*;
/**
 *
 * @author kaustubh
 */
public class OTPS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       User u = new User();
       u.getData();
        // TODO code application logic here
    }
    
}
